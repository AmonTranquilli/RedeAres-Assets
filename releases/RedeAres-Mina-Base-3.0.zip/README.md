# Rede Ares - Mina: base tecnica 3.0

Este pacote e um prototipo de alinhamento para Minecraft Java 1.21.11.
Nao contem a arte final do Rankup Imperio.

O fundo e chamado pelo titulo do menu, com a fonte `redeares:gui/mine_prototype`.
Nenhuma textura global de bau, funil ou shulker e substituida.
Os icones de outros menus do pacote anterior continuam disponiveis.

## Medidas

- Inventario principal: bau de 45 slots, cinco linhas.
- Fundo: 176 x 107 pixels, somente a area superior do menu.
- Titulo vanilla: origem (8,6).
- E000: deslocamento horizontal de -8 pixels.
- E001: imagem bitmap, altura 107, ascent 13.
- Origem final do fundo: (0,0). Sombra e formatacoes de texto desativadas.

## Acoes

| Marca | Slot | Acao |
| --- | --- | --- |
| A | 4 | Perfil, informacoes ao passar o mouse |
| B | 20 | Abrir picareta |
| C | 22 | Entrar ou sair da mina |
| D | 24 | Listar minas publicas |
| E | 40 | Fechar |

Espacos vazios nao executam acoes. Cliques e arrastos sao bloqueados pelo plugin.

## Teste no cliente (etapa seguinte)

1. Parar o servidor com `stop` e iniciar por `iniciar-rankup-1.21.bat`.
2. Reconectar e aceitar o novo resource pack.
3. Abrir `/mina`: o cabecalho deve dizer MINA - BASE TECNICA.
4. Verificar as quatro marcas vermelhas nos cantos e o encaixe dos cinco icones.
5. O texto Inventario e os slots pessoais devem aparecer abaixo do painel.
6. Abrir Spawners, um bau comum, um funil e uma shulker: devem usar o fundo normal.
7. Conferir as escalas de interface 2, 3 e 4 quando disponiveis no cliente.
8. Conferir B, C, D e E; A mostra somente informacoes.

Validacao de codigo, pacote e coordenadas feita localmente.
A renderizacao real no Lunar/Minecraft ainda precisa passar pelo teste acima.
