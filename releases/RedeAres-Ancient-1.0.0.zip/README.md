# Mina Imperial 3.2

Painel original no tamanho nativo da interface do Minecraft Java 1.21.11.
A janela usa seis linhas de bau. Os rotulos usam a fonte do proprio jogo,
sem reducao: texturas vanilla de fonte referenciadas por fontes com posicao
vertical ajustada. O titulo usa os mesmos pixels nativos na placa elevada.

O fundo foi construido em 176x140 pixels, sem redimensionamento de uma arte
grande. Luz, sombra, rebaixos e bordas tem espessura de pixels inteiros.
Os 12 pixels superiores formam a placa elevada; a sombra inferior termina
antes do rotulo do inventario do jogador.

Perfil: slot 4. Picareta: slot 28. Minerar/Sair: slot 31.
Minas Publicas: slot 34. Fechar: slot 49.

O pacote nao sobrescreve texturas globais do Minecraft. Requer o plugin
AresPrivateMines correspondente. Os icones dos outros menus continuam
disponiveis no pacote.

Para ativar, parar o servidor com stop e iniciar por iniciar-rankup-1.21.bat.
Reconectar, aceitar o pacote e abrir /mina. A renderizacao final precisa
ser conferida no cliente, incluindo entrada, saida e escalas de interface.
