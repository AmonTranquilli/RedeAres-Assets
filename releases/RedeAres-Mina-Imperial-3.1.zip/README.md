# Rede Ares - Mina Imperial 3.1

Arte original aprovada para a tela principal `/mina` no Minecraft Java 1.21.11.
Pedra clara, ouro envelhecido, contrastes grafite e detalhes vinho.

## Implementacao

O fundo aparece por uma fonte exclusiva no titulo de um bau de 45 slots.
A fonte `redeares:gui/mine_imperial` usa duas metades em resolucao 2x para
preservar os detalhes e respeitar o limite de tamanho de celulas do atlas.
Cada metade tem 176x214 pixels e renderiza em 88x107 pixels.
O deslocamento inicial e -8 e o deslocamento entre metades e -1.
Ascent 13 posiciona a arte na origem do inventario, como na base 3.0 validada.

Nenhum recurso do namespace minecraft e substituido.
Baús, funis, shulkers e demais menus continuam com seus proprios fundos.

## Botoes

- Slot 4: perfil e informacoes da mina (tooltip).
- Slot 20: picareta.
- Slot 22: minerar fora da mina / sair quando ja estiver dentro.
- Slot 24: Minas Publicas.
- Slot 40: fechar.

A arte tambem troca MINERAR por SAIR conforme o estado do jogador.
Os itens continuam no tamanho normal e nas mesmas posicoes testadas na 3.0.

## Ativacao e verificacao

Parar com `stop`, iniciar por `iniciar-rankup-1.21.bat` e reconectar.
O novo pacote sera solicitado automaticamente. Abrir `/mina` e conferir
o fundo MINA IMPERIAL e a opcao MINAS PUBLICAS. Conferir tambem o estado SAIR.

O pacote e o plugin foram verificados localmente. A base foi validada pelo
usuario no Lunar; a arte final precisa da conferencia visual nesse cliente.
