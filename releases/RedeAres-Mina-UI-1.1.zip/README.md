# Rede Ares — Mina Privada UI

Resource pack para Paper 1.21.11. Ele fornece doze ícones da interface da Mina Privada no namespace `redeares:mine_ui/*`.

## Instalação

1. Publique o arquivo `RedeAres-Mina-UI-1.1.zip` em uma URL HTTPS direta.
2. Em `server.properties`, defina `resource-pack` para essa URL e `resource-pack-sha1` para o SHA-1 informado ao lado do ZIP.
3. Com o servidor desligado, substitua o JAR existente de `AresPrivateMines` pelo JAR `AresPrivateMines-ui-1.0.jar`. Não deixe ambos na pasta `plugins`.
4. Reinicie o Paper e aceite o pack ao entrar.

Sem o pack, os menus continuam funcionando e mostram os itens padrão do Minecraft.

## Ícones

`profile`, `pickaxe`, `enter`, `public`, `exit`, `reset`, `auto_reset`, `powers`, `bossbar`, `tax`, `collect` e `close`.

## Alteração do plugin

Os itens recebem o componente `item_model` com o namespace `redeares`. O comportamento de cada botão continua definido pelo slot do inventário. Também foi ligado o cartão de Evolução da Mina ao slot superior central do painel do gerente.
