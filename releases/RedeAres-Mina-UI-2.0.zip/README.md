# Rede Ares — Resource Pack (Interface Mina Privada 2.0)

Resource pack modernizado para **Paper 1.21.11**, baseado no design de referência com **3 grandes cartões** e **botão fechar [X]**.

## O que mudou na Versão 2.0:
1. **Removida a substituição de `hopper.png`**: Restaurada a aparência original dos funis normais no Minecraft (eliminando a barra amarela com texto sobreposto).
2. **Novos Cartões Grandes**:
   - `redeares:mine_ui/card_amigos`: Painel de Amigos e Minas Públicas
   - `redeares:mine_ui/card_teleport`: Cartão principal "Ir minerar!" (Entrar na mina)
   - `redeares:mine_ui/card_armor`: Equipamentos, Armadura & Picareta
   - `redeares:mine_ui/btn_close`: Botão estilizado [X] para fechar o menu
3. **Menu em Baú de 27 Slots**: O menu `/mina` agora ocupa uma interface espaçosa de baú, onde as 3 colunas de cada cartão são clicáveis como botões gigantes.
4. **Ícones do Gerenciador Mantidos**: Todos os ícones do painel de gerenciamento interno (`reset`, `auto_reset`, `powers`, `bossbar`, `tax`, `collect`, `profile`, `pickaxe`) continuam ativos para as telas de sub-menus.

## Instalação e Atualização no GitHub:
1. Envie o arquivo ZIP gerado (`RedeAres-Mina-UI-2.0.zip`) para o repositório no GitHub:
   `https://github.com/AmonTranquilli/RedeAres-Assets` na pasta `releases/`.
2. Em `server.properties`, aponte a URL direta e o hash SHA-1 do arquivo.
